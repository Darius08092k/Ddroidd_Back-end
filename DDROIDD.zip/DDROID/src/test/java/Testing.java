/*import Project.Products;
import org.testng.annotations.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Testing {
    @Test
    void justAnExample() {
        assertEquals(164.99, )
    }
}*/
