package Project;

public class Main {
    public static void main(String[] args) {
        Products products = new Products();

      products.showItems();
      products.selectItems();


    }
}
